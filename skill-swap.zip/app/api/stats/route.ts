import { type NextRequest, NextResponse } from "next/server"
import { userService } from "@/lib/services/userService"
import { swapService } from "@/lib/services/swapService"

export async function GET(request: NextRequest) {
  try {
    const [users, swaps] = await Promise.all([userService.getAllUsers(), swapService.getAllSwaps()])

    const stats = {
      totalUsers: users.length,
      activeUsers: users.filter((user) => user.isOnline).length,
      totalSwaps: swaps.length,
      completedSwaps: swaps.filter((swap) => swap.status === "completed").length,
      pendingSwaps: swaps.filter((swap) => swap.status === "pending").length,
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Stats error:", error)
    // Return fallback stats if database is unavailable
    return NextResponse.json({
      totalUsers: 0,
      activeUsers: 0,
      totalSwaps: 0,
      completedSwaps: 0,
      pendingSwaps: 0,
    })
  }
}
