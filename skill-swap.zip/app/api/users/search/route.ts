import { type NextRequest, NextResponse } from "next/server"
import { userService } from "@/lib/services/userService"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q") || ""
    const skills = searchParams.get("skills")?.split(",").filter(Boolean) || []

    const users = await userService.searchUsers(query, skills)

    // Remove passwords from response
    const safeUsers = users.map(({ password, ...user }) => user)

    return NextResponse.json({ users: safeUsers })
  } catch (error) {
    console.error("Search users error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
