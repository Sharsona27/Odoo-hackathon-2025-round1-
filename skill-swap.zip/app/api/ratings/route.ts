import { type NextRequest, NextResponse } from "next/server"
import { swapService } from "@/lib/services/swapService"
import { ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "skill_swap_secret_key_mahima_2025"

function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value
  if (!token) return null

  try {
    return jwt.verify(token, JWT_SECRET) as { userId: string; email: string }
  } catch {
    return null
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const body = await request.json()
    const { swapRequestId, rating, feedback } = body

    // Validate required fields
    if (!swapRequestId || !rating) {
      return NextResponse.json({ error: "Swap request ID and rating are required" }, { status: 400 })
    }

    // Get the swap request to determine the other user
    const swapRequest = await swapService.getSwapRequestById(swapRequestId)
    if (!swapRequest) {
      return NextResponse.json({ error: "Swap request not found" }, { status: 404 })
    }

    // Determine who to rate (the other person in the swap)
    const toUserId = swapRequest.fromUserId.toString() === user.userId ? swapRequest.toUserId : swapRequest.fromUserId

    const ratingData = await swapService.addRating({
      swapRequestId: new ObjectId(swapRequestId),
      fromUserId: new ObjectId(user.userId),
      toUserId: new ObjectId(toUserId),
      rating: Number(rating),
      feedback: feedback || "",
    })

    return NextResponse.json(
      {
        message: "Rating submitted successfully",
        rating: ratingData,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Submit rating error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
