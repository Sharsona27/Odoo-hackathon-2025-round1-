import { type NextRequest, NextResponse } from "next/server"
import { swapService } from "@/lib/services/swapService"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "skill_swap_secret_key_mahima_2025"

function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value
  if (!token) return null

  try {
    return jwt.verify(token, JWT_SECRET) as { userId: string; email: string }
  } catch {
    return null
  }
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const body = await request.json()
    const { status, scheduledDate } = body

    const success = await swapService.updateSwapRequestStatus(
      params.id,
      status,
      scheduledDate ? new Date(scheduledDate) : undefined,
    )

    if (!success) {
      return NextResponse.json({ error: "Failed to update swap request" }, { status: 400 })
    }

    return NextResponse.json({
      message: "Swap request updated successfully",
    })
  } catch (error) {
    console.error("Update swap request error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const success = await swapService.deleteSwapRequest(params.id, user.userId)

    if (!success) {
      return NextResponse.json({ error: "Failed to delete swap request or request not found" }, { status: 400 })
    }

    return NextResponse.json({
      message: "Swap request deleted successfully",
    })
  } catch (error) {
    console.error("Delete swap request error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
