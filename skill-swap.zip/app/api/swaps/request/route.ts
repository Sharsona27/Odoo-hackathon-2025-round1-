import { type NextRequest, NextResponse } from "next/server"
import { swapService } from "@/lib/services/swapService"
import { ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "skill_swap_secret_key_mahima_2025"

function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value
  if (!token) return null

  try {
    return jwt.verify(token, JWT_SECRET) as { userId: string; email: string }
  } catch {
    return null
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const body = await request.json()
    const { toUserId, offeredSkill, requestedSkill, message } = body

    // Validate required fields
    if (!toUserId || !offeredSkill || !requestedSkill) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Check if user is trying to send request to themselves
    if (user.userId === toUserId) {
      return NextResponse.json({ error: "Cannot send swap request to yourself" }, { status: 400 })
    }

    const swapRequest = await swapService.createSwapRequest({
      fromUserId: new ObjectId(user.userId),
      toUserId: new ObjectId(toUserId),
      offeredSkill,
      requestedSkill,
      message,
      status: "pending",
    })

    return NextResponse.json(
      {
        message: "Swap request sent successfully",
        swapRequest,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Create swap request error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const type = (searchParams.get("type") as "sent" | "received" | "all") || "all"

    const swapRequests = await swapService.getSwapRequestsForUser(user.userId, type)

    return NextResponse.json({
      swapRequests,
    })
  } catch (error) {
    console.error("Get swap requests error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
