"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, Users, Star, ArrowRight, Sparkles, Zap, Heart } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeSwaps: 0,
    completedSwaps: 0,
  })

  useEffect(() => {
    fetchStats()
  }, [])

  const fetchStats = async () => {
    try {
      const response = await fetch("/api/stats")
      if (response.ok) {
        const data = await response.json()
        setStats({
          totalUsers: data.users.totalUsers,
          activeSwaps: data.swaps.activeSwaps,
          completedSwaps: data.swaps.completedSwaps,
        })
      }
    } catch (error) {
      console.error("Error fetching stats:", error)
    }
  }

  const featuredSkills = [
    { name: "Web Development", count: 245, icon: "💻" },
    { name: "Graphic Design", count: 189, icon: "🎨" },
    { name: "Photography", count: 156, icon: "📸" },
    { name: "Language Exchange", count: 203, icon: "🗣️" },
    { name: "Music Production", count: 98, icon: "🎵" },
    { name: "Cooking", count: 167, icon: "👨‍🍳" },
  ]

  const testimonials = [
    {
      name: "Sarah Chen",
      skill: "Learned Python",
      avatar: "/placeholder.svg?height=40&width=40",
      text: "Amazing platform! I taught design and learned coding in return.",
    },
    {
      name: "Mike Johnson",
      skill: "Taught Guitar",
      avatar: "/placeholder.svg?height=40&width=40",
      text: "Found the perfect language exchange partner here!",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              SkillSwap
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/browse">
              <Button variant="ghost" className="text-purple-600 hover:text-purple-700">
                Browse Skills
              </Button>
            </Link>
            <Link href="/auth">
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="container mx-auto px-4 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-[600px]">
            {/* Left Side - Content */}
            <div className="relative z-10 animate-fade-in-up">
              <div className="space-y-8">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 border border-white/30">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium text-gray-700">{stats.totalUsers}+ Active Learners</span>
                  </div>

                  <h1 className="text-5xl md:text-7xl font-black leading-tight">
                    <span className="block text-gray-900">Swap</span>
                    <span className="block bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 bg-clip-text text-transparent">
                      Skills
                    </span>
                    <span className="block text-gray-900">Grow</span>
                    <span className="block bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                      Together
                    </span>
                  </h1>
                </div>

                <p className="text-xl text-gray-600 max-w-lg leading-relaxed">
                  Connect with amazing people, teach what you love, and learn something incredible. Your next skill
                  adventure starts here! 🚀
                </p>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/auth">
                    <Button
                      size="lg"
                      className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 text-lg font-semibold rounded-2xl shadow-xl hover:shadow-2xl transform hover:-translate-y-1 transition-all duration-300"
                    >
                      Start Swapping
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                  <Link href="/browse">
                    <Button
                      variant="outline"
                      size="lg"
                      className="border-2 border-purple-200 text-purple-600 hover:bg-purple-50 px-8 py-4 text-lg font-semibold rounded-2xl bg-white/80 backdrop-blur-sm"
                    >
                      Browse Skills
                      <Search className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                </div>

                {/* Quick Stats */}
                <div className="flex items-center gap-8 pt-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">1,200+</div>
                    <div className="text-sm text-gray-600">Skills</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-pink-600">{stats.completedSwaps}+</div>
                    <div className="text-sm text-gray-600">Swaps</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-indigo-600">4.9★</div>
                    <div className="text-sm text-gray-600">Rating</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side - Creative Illustration Area */}
            <div className="relative animate-fade-in-up animation-delay-300">
              {/* Main Illustration Container */}
              <div className="relative w-full h-[500px] lg:h-[600px]">
                {/* Background Shapes */}
                <div className="absolute inset-0">
                  <div className="absolute top-10 right-10 w-32 h-32 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full opacity-20 animate-bounce-gentle"></div>
                  <div className="absolute bottom-20 left-10 w-24 h-24 bg-gradient-to-br from-indigo-400 to-purple-400 rounded-full opacity-30 animate-bounce-gentle animation-delay-200"></div>
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-gradient-to-br from-pink-400 to-indigo-400 rounded-full opacity-10"></div>
                </div>

                {/* Floating Skill Cards */}
                <div className="absolute top-16 left-8 animate-float">
                  <div className="bg-white rounded-xl shadow-lg p-4 border border-purple-100 transform rotate-12">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                        <span className="text-white text-sm">💻</span>
                      </div>
                      <span className="font-semibold text-sm">React</span>
                    </div>
                  </div>
                </div>

                <div className="absolute top-32 right-16 animate-float animation-delay-200">
                  <div className="bg-white rounded-xl shadow-lg p-4 border border-pink-100 transform -rotate-6">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-indigo-500 rounded-lg flex items-center justify-center">
                        <span className="text-white text-sm">🎨</span>
                      </div>
                      <span className="font-semibold text-sm">Design</span>
                    </div>
                  </div>
                </div>

                <div className="absolute bottom-32 left-16 animate-float animation-delay-400">
                  <div className="bg-white rounded-xl shadow-lg p-4 border border-indigo-100 transform rotate-6">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                        <span className="text-white text-sm">🗣️</span>
                      </div>
                      <span className="font-semibold text-sm">Spanish</span>
                    </div>
                  </div>
                </div>

                <div className="absolute bottom-16 right-8 animate-float animation-delay-600">
                  <div className="bg-white rounded-xl shadow-lg p-4 border border-green-100 transform -rotate-12">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-teal-500 rounded-lg flex items-center justify-center">
                        <span className="text-white text-sm">📸</span>
                      </div>
                      <span className="font-semibold text-sm">Photo</span>
                    </div>
                  </div>
                </div>

                {/* Central Character Illustration */}
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="relative">
                    {/* Main Circle Background */}
                    <div className="w-64 h-64 bg-gradient-to-br from-purple-100 via-pink-100 to-indigo-100 rounded-full flex items-center justify-center border-4 border-white shadow-2xl">
                      {/* Character Representation */}
                      <div className="text-center space-y-4">
                        <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full mx-auto flex items-center justify-center shadow-lg">
                          <Users className="w-10 h-10 text-white" />
                        </div>
                        <div className="space-y-2">
                          <div className="text-lg font-bold text-gray-800">Connect</div>
                          <div className="text-sm text-gray-600">Learn • Teach • Grow</div>
                        </div>
                      </div>
                    </div>

                    {/* Orbiting Elements */}
                    <div className="absolute inset-0 animate-spin-slow">
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                        <div className="w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center shadow-lg">
                          <Sparkles className="w-4 h-4 text-white" />
                        </div>
                      </div>
                      <div className="absolute top-1/2 -right-4 transform -translate-y-1/2">
                        <div className="w-8 h-8 bg-green-400 rounded-full flex items-center justify-center shadow-lg">
                          <Heart className="w-4 h-4 text-white" />
                        </div>
                      </div>
                      <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2">
                        <div className="w-8 h-8 bg-blue-400 rounded-full flex items-center justify-center shadow-lg">
                          <Zap className="w-4 h-4 text-white" />
                        </div>
                      </div>
                      <div className="absolute top-1/2 -left-4 transform -translate-y-1/2">
                        <div className="w-8 h-8 bg-red-400 rounded-full flex items-center justify-center shadow-lg">
                          <Star className="w-4 h-4 text-white" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Connection Lines */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-30">
                  <defs>
                    <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#8b5cf6" />
                      <stop offset="50%" stopColor="#ec4899" />
                      <stop offset="100%" stopColor="#6366f1" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M 100 150 Q 200 100 300 200 T 450 180"
                    stroke="url(#lineGradient)"
                    strokeWidth="2"
                    fill="none"
                    strokeDasharray="5,5"
                    className="animate-pulse"
                  />
                  <path
                    d="M 150 400 Q 250 350 350 450 T 500 420"
                    stroke="url(#lineGradient)"
                    strokeWidth="2"
                    fill="none"
                    strokeDasharray="5,5"
                    className="animate-pulse animation-delay-200"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Background Decorations */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-purple-200 to-pink-200 rounded-full opacity-20"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-indigo-200 to-purple-200 rounded-full opacity-20"></div>
        </div>
      </section>

      {/* Featured Skills */}
      <section className="py-16 px-4 bg-white/50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Popular Skills to Swap</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredSkills.map((skill, index) => (
              <Card
                key={skill.name}
                className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-purple-100 hover:border-purple-300 animate-fade-in-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">{skill.icon}</div>
                  <h3 className="font-semibold text-lg mb-2">{skill.name}</h3>
                  <p className="text-gray-600 mb-4">{skill.count} people offering</p>
                  <Button
                    variant="outline"
                    className="border-purple-200 text-purple-600 hover:bg-purple-50 bg-transparent"
                  >
                    Explore <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">How SkillSwap Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center animate-fade-in-up">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">1. Create Your Profile</h3>
              <p className="text-gray-600">
                List your skills and what you'd like to learn. Add your availability and preferences.
              </p>
            </div>
            <div className="text-center animate-fade-in-up animation-delay-200">
              <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">2. Find & Connect</h3>
              <p className="text-gray-600">Browse skills, send swap requests, and connect with like-minded learners.</p>
            </div>
            <div className="text-center animate-fade-in-up animation-delay-400">
              <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">3. Learn & Teach</h3>
              <p className="text-gray-600">
                Meet up, share knowledge, and rate your experience to help the community grow.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 bg-gradient-to-r from-purple-100 to-pink-100">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">What Our Community Says</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <Card
                key={testimonial.name}
                className="animate-fade-in-up border-purple-200"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <Avatar>
                      <AvatarImage src={testimonial.avatar || "/placeholder.svg"} />
                      <AvatarFallback>{testimonial.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-semibold">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.skill}</p>
                    </div>
                  </div>
                  <p className="text-gray-700 mb-4">"{testimonial.text}"</p>
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Start Swapping?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of learners and start your skill exchange journey today!
          </p>
          <Link href="/auth">
            <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-3 text-lg">
              Join SkillSwap Now
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">SkillSwap</span>
          </div>
          <p className="text-gray-400 mb-4">Connecting learners worldwide</p>
          <div className="flex justify-center gap-6 text-sm text-gray-400">
            <a href="#" className="hover:text-white">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-white">
              Terms of Service
            </a>
            <a href="#" className="hover:text-white">
              Contact Us
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}
