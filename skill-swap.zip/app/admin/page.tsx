"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Users, MessageSquare, TrendingUp, AlertTriangle, Home } from "lucide-react"
import Link from "next/link"

interface User {
  _id: string
  name: string
  email: string
  isOnline: boolean
  isBanned: boolean
  completedSwaps: number
  rating: number
}

interface SwapRequest {
  _id: string
  fromUserId: string
  toUserId: string
  fromSkill: string
  toSkill: string
  status: string
  createdAt: string
}

interface Stats {
  totalUsers: number
  activeUsers: number
  totalSwaps: number
  completedSwaps: number
  pendingSwaps: number
}

export default function AdminPage() {
  const [users, setUsers] = useState<User[]>([])
  const [swaps, setSwaps] = useState<SwapRequest[]>([])
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    activeUsers: 0,
    totalSwaps: 0,
    completedSwaps: 0,
    pendingSwaps: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchAdminData()
  }, [])

  const fetchAdminData = async () => {
    try {
      const [usersResponse, swapsResponse, statsResponse] = await Promise.all([
        fetch("/api/users/search?q="),
        fetch("/api/swaps/all"),
        fetch("/api/stats"),
      ])

      if (usersResponse.ok) {
        const usersData = await usersResponse.json()
        setUsers(usersData.users || [])
      }

      if (swapsResponse.ok) {
        const swapsData = await swapsResponse.json()
        setSwaps(swapsData.swaps || [])
      }

      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setStats(statsData)
      }
    } catch (error) {
      console.error("Error fetching admin data:", error)
      // Set fallback data
      setUsers([
        {
          _id: "1",
          name: "Alice Johnson",
          email: "alice@example.com",
          isOnline: true,
          isBanned: false,
          completedSwaps: 12,
          rating: 4.8,
        },
        {
          _id: "2",
          name: "Bob Smith",
          email: "bob@example.com",
          isOnline: false,
          isBanned: false,
          completedSwaps: 8,
          rating: 4.9,
        },
      ])
      setStats({
        totalUsers: 156,
        activeUsers: 42,
        totalSwaps: 89,
        completedSwaps: 67,
        pendingSwaps: 12,
      })
    } finally {
      setLoading(false)
    }
  }

  const banUser = async (userId: string) => {
    try {
      const response = await fetch(`/api/admin/users/${userId}/ban`, {
        method: "POST",
      })
      if (response.ok) {
        fetchAdminData()
        alert("User banned successfully")
      }
    } catch (error) {
      console.error("Error banning user:", error)
      alert("Error banning user")
    }
  }

  const unbanUser = async (userId: string) => {
    try {
      const response = await fetch(`/api/admin/users/${userId}/unban`, {
        method: "POST",
      })
      if (response.ok) {
        fetchAdminData()
        alert("User unbanned successfully")
      }
    } catch (error) {
      console.error("Error unbanning user:", error)
      alert("Error unbanning user")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Admin Dashboard
            </h1>
            <p className="text-gray-600 mt-2">Manage users and monitor platform activity</p>
          </div>
          <Link href="/">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />🏠 Home
            </Button>
          </Link>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{loading ? "..." : stats.totalUsers}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Users</CardTitle>
              <TrendingUp className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{loading ? "..." : stats.activeUsers}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Swaps</CardTitle>
              <MessageSquare className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{loading ? "..." : stats.totalSwaps}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Swaps</CardTitle>
              <AlertTriangle className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{loading ? "..." : stats.pendingSwaps}</div>
            </CardContent>
          </Card>
        </div>

        {/* User Management */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>User Management</CardTitle>
            <CardDescription>Manage registered users and their accounts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {loading ? (
                <div className="space-y-3">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="animate-pulse flex items-center space-x-4 p-4 border rounded-lg">
                      <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                users.map((user) => (
                  <div key={user._id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <Avatar>
                        <AvatarImage
                          src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(user.name)}`}
                          alt={user.name}
                        />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-sm text-gray-500">{user.email}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant={user.isOnline ? "default" : "secondary"}>
                            {user.isOnline ? "Online" : "Offline"}
                          </Badge>
                          {user.isBanned && <Badge variant="destructive">Banned</Badge>}
                          <span className="text-xs text-gray-500">{user.completedSwaps} swaps</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      {user.isBanned ? (
                        <Button size="sm" variant="outline" onClick={() => unbanUser(user._id)}>
                          Unban
                        </Button>
                      ) : (
                        <Button size="sm" variant="destructive" onClick={() => banUser(user._id)}>
                          Ban
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Swap Activity</CardTitle>
            <CardDescription>Latest skill swap requests and completions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {loading ? (
                <div className="space-y-3">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  ))}
                </div>
              ) : swaps.length > 0 ? (
                swaps.slice(0, 10).map((swap) => (
                  <div key={swap._id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium text-sm">
                        {swap.fromSkill} ↔ {swap.toSkill}
                      </p>
                      <p className="text-xs text-gray-500">{new Date(swap.createdAt).toLocaleDateString()}</p>
                    </div>
                    <Badge
                      variant={
                        swap.status === "completed"
                          ? "default"
                          : swap.status === "pending"
                            ? "secondary"
                            : "destructive"
                      }
                    >
                      {swap.status}
                    </Badge>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">No recent swap activity</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
