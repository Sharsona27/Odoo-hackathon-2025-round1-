"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, Plus, X, Home } from "lucide-react"
import Link from "next/link"

interface User {
  _id?: string
  name: string
  email: string
  bio: string
  skills: { name: string; level: string }[]
  avatar: string
  rating: number
  completedSwaps: number
}

export default function ProfilePage() {
  const [user, setUser] = useState<User>({
    name: "",
    email: "",
    bio: "",
    skills: [],
    avatar: "",
    rating: 5.0,
    completedSwaps: 0,
  })
  const [newSkill, setNewSkill] = useState("")
  const [newSkillLevel, setNewSkillLevel] = useState("Beginner")
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetchUserProfile()
  }, [])

  const fetchUserProfile = async () => {
    try {
      const response = await fetch("/api/users/profile")
      if (response.ok) {
        const userData = await response.json()
        setUser(userData.user)
      } else {
        // Fallback user data
        setUser({
          name: "John Doe",
          email: "john@example.com",
          bio: "Passionate developer and lifelong learner",
          skills: [
            { name: "JavaScript", level: "Advanced" },
            { name: "React", level: "Intermediate" },
          ],
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=John",
          rating: 4.7,
          completedSwaps: 5,
        })
      }
    } catch (error) {
      console.error("Error fetching profile:", error)
      // Set fallback data
      setUser({
        name: "John Doe",
        email: "john@example.com",
        bio: "Passionate developer and lifelong learner",
        skills: [
          { name: "JavaScript", level: "Advanced" },
          { name: "React", level: "Intermediate" },
        ],
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=John",
        rating: 4.7,
        completedSwaps: 5,
      })
    } finally {
      setLoading(false)
    }
  }

  const addSkill = () => {
    if (newSkill.trim()) {
      setUser((prev) => ({
        ...prev,
        skills: [...prev.skills, { name: newSkill.trim(), level: newSkillLevel }],
      }))
      setNewSkill("")
      setNewSkillLevel("Beginner")
    }
  }

  const removeSkill = (index: number) => {
    setUser((prev) => ({
      ...prev,
      skills: prev.skills.filter((_, i) => i !== index),
    }))
  }

  const saveProfile = async () => {
    setSaving(true)
    try {
      const response = await fetch("/api/users/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user),
      })

      if (response.ok) {
        alert("Profile updated successfully!")
      } else {
        alert("Failed to update profile")
      }
    } catch (error) {
      console.error("Error saving profile:", error)
      alert("Error saving profile")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              My Profile
            </h1>
            <p className="text-gray-600 mt-2">Manage your skills and information</p>
          </div>
          <Link href="/">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />🏠 Home
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Overview */}
          <Card className="lg:col-span-1">
            <CardHeader className="text-center">
              <Avatar className="h-24 w-24 mx-auto mb-4">
                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                <AvatarFallback className="text-2xl">{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <CardTitle className="text-xl">{user.name}</CardTitle>
              <CardDescription>{user.email}</CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="flex items-center justify-center space-x-2">
                <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                <span className="font-semibold">{user.rating}</span>
                <span className="text-gray-500">rating</span>
              </div>
              <div>
                <span className="font-semibold text-2xl">{user.completedSwaps}</span>
                <p className="text-gray-500">completed swaps</p>
              </div>
              <div className="pt-4">
                <h4 className="font-semibold mb-2">Skills</h4>
                <div className="flex flex-wrap gap-2 justify-center">
                  {user.skills.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {skill.name}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Edit Form */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Edit Profile</CardTitle>
              <CardDescription>Update your information and skills</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <Input
                    value={user.name}
                    onChange={(e) => setUser((prev) => ({ ...prev, name: e.target.value }))}
                    placeholder="Your full name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <Input
                    type="email"
                    value={user.email}
                    onChange={(e) => setUser((prev) => ({ ...prev, email: e.target.value }))}
                    placeholder="your.email@example.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Bio</label>
                <Textarea
                  value={user.bio}
                  onChange={(e) => setUser((prev) => ({ ...prev, bio: e.target.value }))}
                  placeholder="Tell others about yourself and your interests..."
                  rows={4}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Skills</label>
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-2">
                    {user.skills.map((skill, index) => (
                      <div key={index} className="flex items-center bg-gray-100 rounded-full px-3 py-1">
                        <span className="text-sm mr-2">
                          {skill.name} ({skill.level})
                        </span>
                        <button onClick={() => removeSkill(index)} className="text-red-500 hover:text-red-700">
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Input
                      value={newSkill}
                      onChange={(e) => setNewSkill(e.target.value)}
                      placeholder="Add a skill..."
                      className="flex-1"
                    />
                    <select
                      value={newSkillLevel}
                      onChange={(e) => setNewSkillLevel(e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="Beginner">Beginner</option>
                      <option value="Intermediate">Intermediate</option>
                      <option value="Advanced">Advanced</option>
                      <option value="Expert">Expert</option>
                    </select>
                    <Button onClick={addSkill} size="sm">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-4">
                <Button variant="outline" onClick={fetchUserProfile}>
                  Cancel
                </Button>
                <Button onClick={saveProfile} disabled={saving}>
                  {saving ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
