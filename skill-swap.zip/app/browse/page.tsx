"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, Star, Home } from "lucide-react"
import { ChatDialog } from "@/components/chat-dialog"
import Link from "next/link"

interface User {
  _id: string
  name: string
  email: string
  skills: { name: string; level: string }[]
  bio: string
  avatar: string
  rating: number
  completedSwaps: number
  isOnline: boolean
}

export default function BrowsePage() {
  const [users, setUsers] = useState<User[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchUsers()
  }, [searchQuery])

  const fetchUsers = async () => {
    try {
      const response = await fetch(`/api/users/search?q=${encodeURIComponent(searchQuery)}`)
      if (response.ok) {
        const data = await response.json()
        setUsers(data.users || [])
      }
    } catch (error) {
      console.error("Error fetching users:", error)
      // Fallback data
      setUsers([
        {
          _id: "1",
          name: "Alice Johnson",
          email: "alice@example.com",
          skills: [
            { name: "React", level: "Advanced" },
            { name: "TypeScript", level: "Intermediate" },
          ],
          bio: "Full-stack developer with 5 years of experience",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alice",
          rating: 4.8,
          completedSwaps: 12,
          isOnline: true,
        },
        {
          _id: "2",
          name: "Bob Smith",
          email: "bob@example.com",
          skills: [
            { name: "Python", level: "Expert" },
            { name: "Machine Learning", level: "Advanced" },
          ],
          bio: "Data scientist passionate about AI and ML",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Bob",
          rating: 4.9,
          completedSwaps: 8,
          isOnline: false,
        },
      ])
    } finally {
      setLoading(false)
    }
  }

  const requestSwap = async (toUserId: string, toSkill: string) => {
    try {
      const response = await fetch("/api/swaps/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          toUserId,
          fromSkill: "JavaScript",
          toSkill,
          message: "I'd like to learn this skill from you!",
        }),
      })

      if (response.ok) {
        alert("Swap request sent successfully!")
      } else {
        alert("Failed to send swap request")
      }
    } catch (error) {
      console.error("Error requesting swap:", error)
      alert("Error sending swap request")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Browse Skills
            </h1>
            <p className="text-gray-600 mt-2">Discover talented people and their skills</p>
          </div>
          <Link href="/">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />🏠 Home
            </Button>
          </Link>
        </div>

        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search for skills, people, or expertise..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-24"></div>
                      <div className="h-3 bg-gray-200 rounded w-16"></div>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {users.map((user) => (
              <Card key={user._id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{user.name}</CardTitle>
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm text-gray-600 ml-1">{user.rating}</span>
                          </div>
                          <span className="text-sm text-gray-500">•</span>
                          <span className="text-sm text-gray-600">{user.completedSwaps} swaps</span>
                        </div>
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${user.isOnline ? "bg-green-400" : "bg-gray-300"}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">{user.bio}</CardDescription>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-sm mb-2">Skills:</h4>
                      <div className="flex flex-wrap gap-2">
                        {user.skills.map((skill, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {skill.name} ({skill.level})
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2 pt-2">
                      <Button
                        size="sm"
                        onClick={() => requestSwap(user._id, user.skills[0]?.name || "General")}
                        className="flex-1"
                      >
                        Request Swap
                      </Button>
                      <ChatDialog userName={user.name} userAvatar={user.avatar} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!loading && users.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No users found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  )
}
