"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { CheckCircle, XCircle, Clock, Home } from "lucide-react"
import Link from "next/link"

interface SwapRequest {
  _id: string
  fromUserId: string
  toUserId: string
  fromSkill: string
  toSkill: string
  message: string
  status: "pending" | "accepted" | "rejected" | "completed"
  createdAt: string
  fromUser?: {
    name: string
    avatar: string
  }
  toUser?: {
    name: string
    avatar: string
  }
}

export default function SwapsPage() {
  const [swaps, setSwaps] = useState<SwapRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<"all" | "pending" | "accepted" | "completed">("all")

  useEffect(() => {
    fetchSwaps()
  }, [])

  const fetchSwaps = async () => {
    try {
      const response = await fetch("/api/swaps/user/current")
      if (response.ok) {
        const data = await response.json()
        setSwaps(data.swaps || [])
      } else {
        // Fallback data
        setSwaps([
          {
            _id: "1",
            fromUserId: "user1",
            toUserId: "user2",
            fromSkill: "React",
            toSkill: "Python",
            message: "I'd love to learn Python from you!",
            status: "pending",
            createdAt: new Date().toISOString(),
            fromUser: {
              name: "Alice Johnson",
              avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alice",
            },
            toUser: {
              name: "Bob Smith",
              avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Bob",
            },
          },
          {
            _id: "2",
            fromUserId: "user2",
            toUserId: "user1",
            fromSkill: "Python",
            toSkill: "JavaScript",
            message: "Happy to help with JavaScript!",
            status: "accepted",
            createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
            fromUser: {
              name: "Bob Smith",
              avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Bob",
            },
            toUser: {
              name: "Alice Johnson",
              avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alice",
            },
          },
          {
            _id: "3",
            fromUserId: "user3",
            toUserId: "user1",
            fromSkill: "Design",
            toSkill: "React",
            message: "Would love to trade design skills for React knowledge!",
            status: "completed",
            createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
            fromUser: {
              name: "Carol Wilson",
              avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Carol",
            },
            toUser: {
              name: "Alice Johnson",
              avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alice",
            },
          },
        ])
      }
    } catch (error) {
      console.error("Error fetching swaps:", error)
      setSwaps([])
    } finally {
      setLoading(false)
    }
  }

  const updateSwapStatus = async (swapId: string, status: "accepted" | "rejected" | "completed") => {
    try {
      const response = await fetch(`/api/swaps/${swapId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      })

      if (response.ok) {
        fetchSwaps()
        alert(`Swap ${status} successfully!`)
      } else {
        alert(`Failed to ${status} swap`)
      }
    } catch (error) {
      console.error(`Error updating swap status:`, error)
      alert(`Error updating swap status`)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "accepted":
        return <CheckCircle className="h-4 w-4 text-blue-500" />
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "rejected":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "accepted":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "rejected":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const filteredSwaps = swaps.filter((swap) => filter === "all" || swap.status === filter)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              My Swaps
            </h1>
            <p className="text-gray-600 mt-2">Manage your skill swap requests and offers</p>
          </div>
          <Link href="/">
            <Button variant="outline" size="sm">
              <Home className="h-4 w-4 mr-2" />🏠 Home
            </Button>
          </Link>
        </div>

        {/* Filter Buttons */}
        <div className="flex gap-2 mb-6">
          <Button variant={filter === "all" ? "default" : "outline"} onClick={() => setFilter("all")} size="sm">
            All
          </Button>
          <Button variant={filter === "pending" ? "default" : "outline"} onClick={() => setFilter("pending")} size="sm">
            Pending
          </Button>
          <Button
            variant={filter === "accepted" ? "default" : "outline"}
            onClick={() => setFilter("accepted")}
            size="sm"
          >
            Accepted
          </Button>
          <Button
            variant={filter === "completed" ? "default" : "outline"}
            onClick={() => setFilter("completed")}
            size="sm"
          >
            Completed
          </Button>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                    <div className="space-y-2 flex-1">
                      <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : filteredSwaps.length > 0 ? (
          <div className="space-y-4">
            {filteredSwaps.map((swap) => (
              <Card key={swap._id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage
                          src={
                            swap.fromUser?.avatar ||
                            `https://api.dicebear.com/7.x/avataaars/svg?seed=${swap.fromUserId}`
                          }
                          alt={swap.fromUser?.name || "User"}
                        />
                        <AvatarFallback>{swap.fromUser?.name?.charAt(0) || "U"}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <CardTitle className="text-lg">
                          {swap.fromSkill} ↔ {swap.toSkill}
                        </CardTitle>
                        <CardDescription>
                          {swap.fromUser?.name || "Unknown User"} • {new Date(swap.createdAt).toLocaleDateString()}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(swap.status)}
                      <Badge className={getStatusColor(swap.status)}>{swap.status}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{swap.message}</p>
                  {swap.status === "pending" && (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => updateSwapStatus(swap._id, "accepted")}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        Accept
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => updateSwapStatus(swap._id, "rejected")}>
                        Reject
                      </Button>
                    </div>
                  )}
                  {swap.status === "accepted" && (
                    <Button
                      size="sm"
                      onClick={() => updateSwapStatus(swap._id, "completed")}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Mark as Completed
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-gray-500 text-lg">
                {filter === "all" ? "No swap requests found." : `No ${filter} swaps found.`}
              </p>
              <Link href="/browse">
                <Button className="mt-4">Browse Skills</Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
