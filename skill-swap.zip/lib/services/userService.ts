import { getDatabase } from "@/lib/mongodb"
import type { User } from "@/lib/models/User"
import { ObjectId } from "mongodb"

export class UserService {
  private async getCollection() {
    try {
      const db = await getDatabase()
      return db.collection<User>("users")
    } catch (error) {
      console.error("Database connection error:", error)
      throw new Error("Database unavailable")
    }
  }

  async createUser(userData: Omit<User, "_id" | "createdAt" | "updatedAt">): Promise<User> {
    try {
      const collection = await this.getCollection()
      const now = new Date()
      const user: User = {
        ...userData,
        createdAt: now,
        updatedAt: now,
      }
      const result = await collection.insertOne(user)
      return { ...user, _id: result.insertedId }
    } catch (error) {
      console.error("Error creating user:", error)
      throw new Error("Failed to create user")
    }
  }

  async getUserById(id: string): Promise<User | null> {
    try {
      const collection = await this.getCollection()
      return await collection.findOne({ _id: new ObjectId(id) })
    } catch (error) {
      console.error("Error getting user by ID:", error)
      return null
    }
  }

  async getUserByEmail(email: string): Promise<User | null> {
    try {
      const collection = await this.getCollection()
      return await collection.findOne({ email })
    } catch (error) {
      console.error("Error getting user by email:", error)
      return null
    }
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | null> {
    try {
      const collection = await this.getCollection()
      const result = await collection.findOneAndUpdate(
        { _id: new ObjectId(id) },
        { $set: { ...updates, updatedAt: new Date() } },
        { returnDocument: "after" },
      )
      return result || null
    } catch (error) {
      console.error("Error updating user:", error)
      return null
    }
  }

  async searchUsers(query: string, skills?: string[]): Promise<User[]> {
    try {
      const collection = await this.getCollection()
      const searchFilter: any = {
        $or: [
          { name: { $regex: query, $options: "i" } },
          { bio: { $regex: query, $options: "i" } },
          { "skills.name": { $regex: query, $options: "i" } },
        ],
      }

      if (skills && skills.length > 0) {
        searchFilter["skills.name"] = { $in: skills }
      }

      return await collection.find(searchFilter).limit(20).toArray()
    } catch (error) {
      console.error("Error searching users:", error)
      return []
    }
  }

  async updateUserStatus(id: string, isOnline: boolean): Promise<void> {
    try {
      const collection = await this.getCollection()
      await collection.updateOne({ _id: new ObjectId(id) }, { $set: { isOnline, lastSeen: new Date() } })
    } catch (error) {
      console.error("Error updating user status:", error)
    }
  }

  async getAllUsers(): Promise<User[]> {
    try {
      const collection = await this.getCollection()
      return await collection.find({}).toArray()
    } catch (error) {
      console.error("Error getting all users:", error)
      return []
    }
  }

  async banUser(id: string): Promise<void> {
    try {
      const collection = await this.getCollection()
      await collection.updateOne({ _id: new ObjectId(id) }, { $set: { isBanned: true } })
    } catch (error) {
      console.error("Error banning user:", error)
    }
  }

  async unbanUser(id: string): Promise<void> {
    try {
      const collection = await this.getCollection()
      await collection.updateOne({ _id: new ObjectId(id) }, { $set: { isBanned: false } })
    } catch (error) {
      console.error("Error unbanning user:", error)
    }
  }
}

export const userService = new UserService()
