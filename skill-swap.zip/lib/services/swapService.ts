import { getDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export interface SwapRequest {
  _id?: ObjectId
  fromUserId: string
  toUserId: string
  fromSkill: string
  toSkill: string
  message: string
  status: "pending" | "accepted" | "rejected" | "completed"
  createdAt: Date
  updatedAt: Date
}

export class SwapService {
  private async getCollection() {
    try {
      const db = await getDatabase()
      return db.collection<SwapRequest>("swaps")
    } catch (error) {
      console.error("Database connection error:", error)
      throw new Error("Database unavailable")
    }
  }

  async createSwapRequest(swapData: Omit<SwapRequest, "_id" | "createdAt" | "updatedAt">): Promise<SwapRequest> {
    try {
      const collection = await this.getCollection()
      const now = new Date()
      const swap: SwapRequest = {
        ...swapData,
        status: "pending",
        createdAt: now,
        updatedAt: now,
      }
      const result = await collection.insertOne(swap)
      return { ...swap, _id: result.insertedId }
    } catch (error) {
      console.error("Error creating swap request:", error)
      throw new Error("Failed to create swap request")
    }
  }

  async getSwapsByUserId(userId: string): Promise<SwapRequest[]> {
    try {
      const collection = await this.getCollection()
      return await collection
        .find({
          $or: [{ fromUserId: userId }, { toUserId: userId }],
        })
        .sort({ createdAt: -1 })
        .toArray()
    } catch (error) {
      console.error("Error getting swaps by user ID:", error)
      return []
    }
  }

  async updateSwapStatus(id: string, status: SwapRequest["status"]): Promise<SwapRequest | null> {
    try {
      const collection = await this.getCollection()
      const result = await collection.findOneAndUpdate(
        { _id: new ObjectId(id) },
        { $set: { status, updatedAt: new Date() } },
        { returnDocument: "after" },
      )
      return result || null
    } catch (error) {
      console.error("Error updating swap status:", error)
      return null
    }
  }

  async getAllSwaps(): Promise<SwapRequest[]> {
    try {
      const collection = await this.getCollection()
      return await collection.find({}).sort({ createdAt: -1 }).toArray()
    } catch (error) {
      console.error("Error getting all swaps:", error)
      return []
    }
  }
}

export const swapService = new SwapService()
