import type { ObjectId } from "mongodb"

export interface User {
  _id?: ObjectId
  name: string
  email: string
  password?: string
  location?: string
  profilePhoto?: string
  bio?: string
  skillsOffered: Skill[]
  skillsWanted: Skill[]
  availability: string[]
  isPublic: boolean
  rating: number
  completedSwaps: number
  joinedAt: Date
  lastActive: Date
  isOnline: boolean
  isBanned?: boolean
}

export interface Skill {
  name: string
  level: "Beginner" | "Intermediate" | "Advanced" | "Expert"
  category: string
  description?: string
}

export interface SwapRequest {
  _id?: ObjectId
  fromUserId: ObjectId
  toUserId: ObjectId
  offeredSkill: string
  requestedSkill: string
  message?: string
  status: "pending" | "accepted" | "rejected" | "completed" | "cancelled"
  createdAt: Date
  updatedAt: Date
  scheduledDate?: Date
  completedAt?: Date
}

export interface Rating {
  _id?: ObjectId
  swapRequestId: ObjectId
  fromUserId: ObjectId
  toUserId: ObjectId
  rating: number
  feedback?: string
  createdAt: Date
}

export interface Report {
  _id?: ObjectId
  reportedUserId?: ObjectId
  reportedContent?: string
  reportedBy: ObjectId
  reason: string
  description: string
  type: "user" | "content" | "skill"
  status: "pending" | "under_review" | "resolved" | "dismissed"
  createdAt: Date
  resolvedAt?: Date
  resolvedBy?: ObjectId
}
