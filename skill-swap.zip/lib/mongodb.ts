import { MongoClient, type Db } from "mongodb"

// Get MongoDB URI with fallback
const uri = process.env.MONGODB_URI

// Only validate URI format if it exists (avoid build-time errors)
if (uri && !uri.startsWith("mongodb://") && !uri.startsWith("mongodb+srv://")) {
  console.warn('Invalid MongoDB URI format. Must start with "mongodb://" or "mongodb+srv://"')
}

const options = {
  maxPoolSize: 10,
  serverSelectionTimeoutMS: 5000,
  socketTimeoutMS: 45000,
}

let client: MongoClient
let clientPromise: Promise<MongoClient>

declare global {
  var _mongoClientPromise: Promise<MongoClient> | undefined
}

// Create connection only if URI is available
if (uri) {
  if (process.env.NODE_ENV === "development") {
    if (!global._mongoClientPromise) {
      client = new MongoClient(uri, options)
      global._mongoClientPromise = client.connect()
    }
    clientPromise = global._mongoClientPromise
  } else {
    client = new MongoClient(uri, options)
    clientPromise = client.connect()
  }
} else {
  // Create a mock promise for build time
  clientPromise = Promise.reject(new Error("MongoDB URI not configured"))
}

export default clientPromise

export async function getDatabase(): Promise<Db> {
  try {
    if (!uri) {
      throw new Error("MongoDB URI not configured")
    }
    const client = await clientPromise
    return client.db("skillswap")
  } catch (error) {
    console.error("Failed to connect to MongoDB:", error)
    throw new Error("Database connection failed")
  }
}

export async function testConnection(): Promise<boolean> {
  try {
    if (!uri) {
      console.warn("MongoDB URI not configured")
      return false
    }
    const client = await clientPromise
    await client.db("admin").command({ ping: 1 })
    console.log("MongoDB connection successful")
    return true
  } catch (error) {
    console.error("MongoDB connection failed:", error)
    return false
  }
}
